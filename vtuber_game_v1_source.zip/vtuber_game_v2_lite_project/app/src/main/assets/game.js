const CHARACTERS = {
  wolf: {
    id: "wolf",
    name: "大〇ミオ",
    role: "狼系VTuber",
    room: "assets/wolf_stream_bg.jpg",
    stages: [
      { min: 0, image: "assets/wolf_stage1.webp", label: "初期配信" },
      { min: 5000, image: "assets/wolf_stage2.webp", label: "第2段階" },
      { min: 20000, image: "assets/wolf_stage3.webp", label: "第3段階" },
      { min: 50000, image: "assets/wolf_stage4.webp", label: "最終段階" },
    ],
    chat: ["大〇ミオちゃん待ってた！", "狼系の雰囲気いいね", "今日も応援する！", "この背景似合ってる", "配信たすかる"]
  },
  choco: {
    id: "choco",
    name: "癒〇ちょこ",
    role: "妖艶ナース系VTuber",
    room: "assets/choco_stream_bg.jpg",
    stages: [
      { min: 0, image: "assets/choco_stage1.webp", label: "初期配信" },
      { min: 5000, image: "assets/choco_stage2.webp", label: "第2段階" },
      { min: 20000, image: "assets/choco_stage3.webp", label: "第3段階" },
      { min: 50000, image: "assets/choco_stage4.webp", label: "最終段階" },
    ],
    chat: ["癒〇ちょこちゃんの配信きた！", "ピンクの部屋かわいい", "ナース系の雰囲気いいね", "声が甘くて落ち着く", "今日も投げ銭する！"]
  }
};

const SLOT_ICONS = [
  "assets/slot_wolf.webp", "assets/slot_blonde.webp", "assets/slot_bat.webp", "assets/slot_purple_cat.webp",
  "assets/slot_black_cat.webp", "assets/slot_heart.webp", "assets/slot_flame.webp", "assets/slot_syringe.webp"
];

function loadJson(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch { return fallback; }
}

const migratedTotal = Number(localStorage.getItem("v2_totalTip") || 0);
const state = {
  money: Number(localStorage.getItem("v2_money") || 1000),
  totalTips: loadJson("v23_totalTips", { wolf: migratedTotal, choco: 0 }),
  selectedBet: 100,
  characterId: localStorage.getItem("v2_characterId") || "wolf",
  log: []
};

const $ = (id) => document.getElementById(id);
const yen = (n) => Number(n).toLocaleString("ja-JP");
const activeCharacter = () => CHARACTERS[state.characterId] || CHARACTERS.wolf;
const currentTotal = () => Number(state.totalTips[state.characterId] || 0);

function save() {
  localStorage.setItem("v2_money", String(state.money));
  localStorage.setItem("v23_totalTips", JSON.stringify(state.totalTips));
  localStorage.setItem("v2_characterId", state.characterId);
}

function currentStage() {
  const character = activeCharacter();
  const total = currentTotal();
  let stage = character.stages[0];
  for (const s of character.stages) if (total >= s.min) stage = s;
  return stage;
}

function nextStage() {
  const total = currentTotal();
  return activeCharacter().stages.find(s => total < s.min);
}

const WOLF_FINAL_DIALOGUES = [
  "は、恥ずかしいけど…ウチのおま〇こ見えるかな…？",
  "発情期が強くてヤりまくってるから黒ずんでるけど…許してね…？",
  "ミオファのみんなで好きに使ってください♥",
];

function updateCharacterSpeech() {
  const bubble = $("characterSpeechBubble");
  if (!bubble) return;

  const character = activeCharacter();
  const stage = currentStage();
  const stageIndex = character.stages.indexOf(stage);

  if (character.id === "wolf" && stageIndex === character.stages.length - 1) {
    const index = Math.floor(Date.now() / 4500) % WOLF_FINAL_DIALOGUES.length;
    bubble.textContent = WOLF_FINAL_DIALOGUES[index];
    bubble.classList.remove("hidden");
  } else {
    bubble.classList.add("hidden");
  }
}


function show(screen) {
  ["titleScreen", "streamScreen", "miniGameScreen"].forEach(id => $(id).classList.add("hidden"));
  $(screen).classList.remove("hidden");
  refresh();
  setInterval(updateCharacterSpeech, 1200);
}

function toast(message) {
  const t = $("toast");
  t.textContent = message;
  t.classList.remove("hidden");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.add("hidden"), 1400);
}

function refresh() {
  save();
  const character = activeCharacter();
  const stage = currentStage();
  const index = character.stages.indexOf(stage) + 1;
  const total = currentTotal();

  $("characterImage").src = stage.image;
  $("roomBg").src = character.room;
  $("streamCharacterName").textContent = character.name;
  $("streamCharacterRole").textContent = character.role;
  $("panelCharacterName").textContent = character.name;
  $("panelCharacterRole").textContent = character.role;
  $("moneyText").textContent = yen(state.money);
  $("totalTipText").textContent = yen(total);
  $("stageText").textContent = index;
  $("miniMoneyText").textContent = yen(state.money);

  const next = nextStage();
  $("nextUnlockText").textContent = next ? `次の解放：累計￥${yen(next.min)}で ${next.label}` : "全段階解放済み。最高ランクです。";

  document.querySelectorAll(".tip-button").forEach(btn => {
    const amount = Number(btn.dataset.amount || 0);
    const required = Number(btn.dataset.required || 0);
    const locked = required && total < required;
    btn.classList.toggle("locked", !!locked);
    if (locked) btn.textContent = `￥${yen(amount)}　累計￥${yen(required)}で解放`;
    else btn.textContent = `￥${yen(amount)}　${amount >= 30000 ? "限界応援" : amount >= 10000 ? "VIP投げ銭" : amount >= 3000 ? "応援パック" : amount >= 1000 ? "ギフト" : "小さく応援"}`;
  });
  renderLog();
  updateCharacterSpeech();
}

function addLog(text) {
  state.log.unshift(text);
  state.log = state.log.slice(0, 8);
  renderLog();
}
function renderLog() { $("logList").innerHTML = state.log.map(x => `<div class="log-line">${x}</div>`).join(""); }
function addChat(text) {
  const names = ["推し活勢", "夜更かし民", "匿名さん", "初見さん", "常連さん"];
  const line = document.createElement("div");
  line.className = "chat-line";
  line.innerHTML = `<strong>${names[Math.floor(Math.random() * names.length)]}</strong>：${text}`;
  $("chatList").prepend(line);
  while ($("chatList").children.length > 8) $("chatList").removeChild($("chatList").lastChild);
}
function seedChat() {
  $("chatList").innerHTML = "";
  activeCharacter().chat.slice().reverse().forEach(addChat);
}

function triggerUnlockEffect(label) {
  const effect = $("unlockEffect");
  $("unlockLabel").textContent = label;
  effect.classList.remove("hidden", "active");
  void effect.offsetWidth;
  effect.classList.add("active");
  clearTimeout(triggerUnlockEffect.timer);
  triggerUnlockEffect.timer = setTimeout(() => { effect.classList.remove("active"); effect.classList.add("hidden"); }, 1800);
}

function tip(amount, required) {
  const total = currentTotal();
  if (required && total < required) { addLog(`まだ解放されていません。累計￥${yen(required)}が必要です。`); return; }
  if (state.money < amount) { addLog("所持金が足りません。ミニゲームで稼ぎましょう。"); addChat("ミニゲームで軍資金作ろ！"); return; }
  const oldStage = currentStage();
  state.money -= amount;
  state.totalTips[state.characterId] = total + amount;
  const newStage = currentStage();
  addLog(`￥${yen(amount)} 投げ銭しました。`);
  addChat("ありがとう！ ちゃんと見えてるよ！");
  if (oldStage.image !== newStage.image) {
    addLog(`${newStage.label} が解放されました。`);
    refresh();
    $("characterImage").classList.add("stage-shift");
    triggerUnlockEffect(newStage.label);
    setTimeout(() => $("characterImage").classList.remove("stage-shift"), 520);
    return;
  }
  refresh();
}

function scratch() {
  const prizes = [0, 100, 100, 200, 300, 500, 800, 1000, 2000];
  const prize = prizes[Math.floor(Math.random() * prizes.length)];
  $("scratchCard").textContent = prize ? `￥${yen(prize)}` : "ハズレ";
  $("scratchResult").textContent = prize ? `￥${yen(prize)} 獲得！` : "今回はハズレ…もう一回！";
  if (prize) state.money += prize;
  addLog(prize ? `スクラッチで￥${yen(prize)}獲得。` : "スクラッチはハズレでした。");
  refresh();
}
function setReels(indices) {
  $("reel1").src = SLOT_ICONS[indices[0]];
  $("reel2").src = SLOT_ICONS[indices[1]];
  $("reel3").src = SLOT_ICONS[indices[2]];
}
function spin() {
  const bet = state.selectedBet;
  if (state.money < bet) {
    $("slotMessage").textContent = "BET以上の所持金が必要です";
    addLog("スロット資金が足りません。");
    return;
  }

  state.money -= bet;

  const iconCount = SLOT_ICONS.length;
  let result;
  let payout = 0;
  const roll = Math.random();

  // V2.4: スロットを稼ぎの本命にするため、当たり確率と当選額を強化
  // 3揃い: 約18%、2揃い: 約42%、ハズレ: 約40%
  if (roll < 0.18) {
    const same = Math.floor(Math.random() * iconCount);
    result = [same, same, same];
    payout = bet * 18;
  } else if (roll < 0.60) {
    const pair = Math.floor(Math.random() * iconCount);
    let other = Math.floor(Math.random() * iconCount);
    while (other === pair) other = Math.floor(Math.random() * iconCount);
    const patterns = [[pair, pair, other], [pair, other, pair], [other, pair, pair]];
    result = patterns[Math.floor(Math.random() * patterns.length)];
    payout = bet * 4;
  } else {
    result = [];
    while (result.length < 3) {
      const n = Math.floor(Math.random() * iconCount);
      if (!result.includes(n)) result.push(n);
    }
  }

  setReels(result);

  if (payout > 0) {
    state.money += payout;
    const profit = payout - bet;
    $("slotMessage").textContent = `当たり！ ￥${yen(payout)} 獲得 / 利益 ￥${yen(profit)}`;
    addLog(`スロットで￥${yen(payout)}獲得。`);
  } else {
    $("slotMessage").textContent = `ハズレ… ￥${yen(bet)}消費`;
    addLog(`スロットで￥${yen(bet)}消費。`);
  }

  refresh();
}

function init() {
  seedChat();
  addLog("V2.4確認版を起動しました。");
  document.querySelectorAll(".title-hotspot").forEach(btn => {
    btn.addEventListener("click", () => {
      const id = btn.dataset.character;
      if (CHARACTERS[id]) { state.characterId = id; seedChat(); show("streamScreen"); addLog(`${activeCharacter().name}の配信に入りました。`); }
      else toast("このキャラは次の更新で追加予定です");
    });
  });
  $("titleMiniGameButton").addEventListener("click", () => show("miniGameScreen"));
  $("toTitleFromStream").addEventListener("click", () => show("titleScreen"));
  $("toMiniGameFromStream").addEventListener("click", () => show("miniGameScreen"));
  $("miniToTitle").addEventListener("click", () => show("titleScreen"));
  $("miniToStream").addEventListener("click", () => show("streamScreen"));
  document.querySelectorAll(".tip-button").forEach(btn => btn.addEventListener("click", () => tip(Number(btn.dataset.amount), Number(btn.dataset.required || 0))));
  document.querySelectorAll(".bet-button").forEach(btn => btn.addEventListener("click", () => {
    document.querySelectorAll(".bet-button").forEach(b => b.classList.remove("selected"));
    btn.classList.add("selected"); state.selectedBet = Number(btn.dataset.bet); $("slotMessage").textContent = `BET ￥${yen(state.selectedBet)} を選択中`;
  }));
  $("scratchButton").addEventListener("click", scratch);
  $("scratchCard").addEventListener("click", scratch);
  $("spinButton").addEventListener("click", spin);
  refresh();
}
init();
