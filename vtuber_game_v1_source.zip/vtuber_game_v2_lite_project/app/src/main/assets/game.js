const ASSETS = {
  stages: [
    { min: 0, image: "assets/wolf_stage1.webp", label: "初期配信" },
    { min: 5000, image: "assets/wolf_stage2.webp", label: "第2段階" },
    { min: 20000, image: "assets/wolf_stage3.webp", label: "第3段階" },
    { min: 50000, image: "assets/wolf_stage4.webp", label: "最終段階" },
  ],
  slotIcons: [
    "assets/slot_wolf.webp",
    "assets/slot_blonde.webp",
    "assets/slot_bat.webp",
    "assets/slot_purple_cat.webp",
    "assets/slot_black_cat.webp",
    "assets/slot_heart.webp",
    "assets/slot_flame.webp",
    "assets/slot_syringe.webp",
  ]
};

const state = {
  money: Number(localStorage.getItem("v2_money") || 1000),
  totalTip: Number(localStorage.getItem("v2_totalTip") || 0),
  selectedBet: 100,
  log: [],
};

const $ = (id) => document.getElementById(id);
const yen = (n) => Number(n).toLocaleString("ja-JP");

function save() {
  localStorage.setItem("v2_money", String(state.money));
  localStorage.setItem("v2_totalTip", String(state.totalTip));
}

function currentStage() {
  let stage = ASSETS.stages[0];
  for (const s of ASSETS.stages) {
    if (state.totalTip >= s.min) stage = s;
  }
  return stage;
}

function nextStage() {
  return ASSETS.stages.find(s => state.totalTip < s.min);
}

function show(screen) {
  ["titleScreen", "streamScreen", "miniGameScreen"].forEach(id => $(id).classList.add("hidden"));
  $(screen).classList.remove("hidden");
  refresh();
}

function toast(message) {
  const t = $("toast");
  t.textContent = message;
  t.classList.remove("hidden");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.add("hidden"), 1400);
}

function refresh() {
  save();

  const stage = currentStage();
  const index = ASSETS.stages.indexOf(stage) + 1;
  $("characterImage").src = stage.image;
  $("moneyText").textContent = yen(state.money);
  $("totalTipText").textContent = yen(state.totalTip);
  $("stageText").textContent = index;
  $("miniMoneyText").textContent = yen(state.money);

  const next = nextStage();
  $("nextUnlockText").textContent = next
    ? `次の解放：累計￥${yen(next.min)}で ${next.label}`
    : "全段階解放済み。最高ランクです。";

  document.querySelectorAll(".tip-button").forEach(btn => {
    const amount = Number(btn.dataset.amount || 0);
    const required = Number(btn.dataset.required || 0);
    const locked = required && state.totalTip < required;
    btn.classList.toggle("locked", !!locked);
    if (locked) {
      btn.textContent = `￥${yen(amount)}　累計￥${yen(required)}で解放`;
    } else {
      const label = amount >= 30000 ? "限界応援" : amount >= 10000 ? "VIP投げ銭" : amount >= 3000 ? "応援パック" : amount >= 1000 ? "ギフト" : "小さく応援";
      btn.textContent = `￥${yen(amount)}　${label}`;
    }
  });

  renderLog();
}

function addLog(text) {
  state.log.unshift(text);
  state.log = state.log.slice(0, 8);
  renderLog();
}

function renderLog() {
  $("logList").innerHTML = state.log.map(x => `<div class="log-line">${x}</div>`).join("");
}

function addChat(text) {
  const names = ["推し活勢", "夜更かし民", "狼の民", "匿名さん", "初見さん"];
  const line = document.createElement("div");
  line.className = "chat-line";
  line.innerHTML = `<strong>${names[Math.floor(Math.random() * names.length)]}</strong>：${text}`;
  $("chatList").prepend(line);
  while ($("chatList").children.length > 9) $("chatList").removeChild($("chatList").lastChild);
}

function seedChat() {
  const lines = [
    "大〇ミオちゃん待ってた！",
    "この部屋、黒赤でめっちゃ似合う",
    "狼系の雰囲気いいね",
    "今日は投げ銭するぞー！",
    "声が落ち着く…",
  ];
  $("chatList").innerHTML = "";
  lines.reverse().forEach(addChat);
}

function tip(amount, required) {
  if (required && state.totalTip < required) {
    addLog(`まだ解放されていません。累計￥${yen(required)}が必要です。`);
    addChat("まずは少しずつ応援して解放しよ！");
    return;
  }
  if (state.money < amount) {
    addLog("所持金が足りません。ミニゲームで稼ぎましょう。");
    addChat("ミニゲームで軍資金作ろ！");
    return;
  }

  const oldStage = currentStage();
  state.money -= amount;
  state.totalTip += amount;
  const newStage = currentStage();

  addLog(`￥${yen(amount)} 投げ銭しました。`);
  addChat("ありがとう！ ちゃんと見えてるよ！");
  if (oldStage.image !== newStage.image) {
    addLog(`${newStage.label} が解放されました。`);
    addChat("わっ、特別な配信モードが解放されたよ！");
    $("characterImage").style.transform = "scale(1.035)";
    setTimeout(() => $("characterImage").style.transform = "", 180);
  }
  refresh();
}

function scratch() {
  const prizes = [0, 100, 100, 200, 300, 500, 800, 1000, 2000];
  const prize = prizes[Math.floor(Math.random() * prizes.length)];
  $("scratchCard").textContent = prize ? `￥${yen(prize)}` : "ハズレ";
  $("scratchResult").textContent = prize ? `￥${yen(prize)} 獲得！` : "今回はハズレ…もう一回！";
  if (prize) {
    state.money += prize;
    addLog(`スクラッチで￥${yen(prize)}獲得。`);
  } else {
    addLog("スクラッチはハズレでした。");
  }
  refresh();
}

function setReels(indices) {
  $("reel1").src = ASSETS.slotIcons[indices[0]];
  $("reel2").src = ASSETS.slotIcons[indices[1]];
  $("reel3").src = ASSETS.slotIcons[indices[2]];
}

function spin() {
  const bet = state.selectedBet;
  if (state.money < bet) {
    $("slotMessage").textContent = "BET以上の所持金が必要です";
    addLog("スロット資金が足りません。");
    return;
  }

  state.money -= bet;

  const result = [0, 1, 2].map(() => Math.floor(Math.random() * ASSETS.slotIcons.length));
  setReels(result);

  let payout = 0;
  if (result[0] === result[1] && result[1] === result[2]) {
    payout = bet * 10;
  } else if (result[0] === result[1] || result[1] === result[2] || result[0] === result[2]) {
    payout = bet * 2;
  }

  if (payout > 0) {
    state.money += payout;
    $("slotMessage").textContent = `当たり！ ￥${yen(payout)} 獲得`;
    addLog(`スロットで￥${yen(payout)}獲得。`);
  } else {
    $("slotMessage").textContent = `ハズレ… ￥${yen(bet)}消費`;
    addLog(`スロットで￥${yen(bet)}消費。`);
  }

  refresh();
}

function init() {
  seedChat();
  addLog("V2確認版を起動しました。");

  document.querySelectorAll(".title-hotspot").forEach(btn => {
    btn.addEventListener("click", () => {
      if (btn.dataset.character === "wolf") {
        show("streamScreen");
        addLog("大〇ミオの配信に入りました。");
      } else {
        toast("このキャラは次の更新で追加予定です");
      }
    });
  });

  $("titleMiniGameButton").addEventListener("click", () => show("miniGameScreen"));
  $("toTitleFromStream").addEventListener("click", () => show("titleScreen"));
  $("toMiniGameFromStream").addEventListener("click", () => show("miniGameScreen"));
  $("miniToTitle").addEventListener("click", () => show("titleScreen"));
  $("miniToStream").addEventListener("click", () => show("streamScreen"));

  document.querySelectorAll(".tip-button").forEach(btn => {
    btn.addEventListener("click", () => tip(Number(btn.dataset.amount), Number(btn.dataset.required || 0)));
  });

  document.querySelectorAll(".bet-button").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".bet-button").forEach(b => b.classList.remove("selected"));
      btn.classList.add("selected");
      state.selectedBet = Number(btn.dataset.bet);
      $("slotMessage").textContent = `BET ￥${yen(state.selectedBet)} を選択中`;
    });
  });

  $("scratchButton").addEventListener("click", scratch);
  $("scratchCard").addEventListener("click", scratch);
  $("spinButton").addEventListener("click", spin);

  refresh();
}

init();
