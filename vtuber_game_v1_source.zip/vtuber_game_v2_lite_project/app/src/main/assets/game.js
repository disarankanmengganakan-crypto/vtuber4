
const CHARACTERS = {
  wolf: {
    id: "wolf",
    name: "大〇ミオ",
    role: "狼系VTuber",
    room: "assets/wolf_stream_bg.jpg",
    stages: [
      { min: 0, image: "assets/wolf_stage1.webp", label: "初期配信" },
      { min: 5000, image: "assets/wolf_stage2.webp", label: "第2段階" },
      { min: 20000, image: "assets/wolf_stage3.webp", label: "第3段階" },
      { min: 50000, image: "assets/wolf_stage4.webp", label: "最終段階" },
    ],
    chat: ["大〇ミオちゃん待ってた！", "狼系の雰囲気いいね", "今日も応援する！", "この背景似合ってる", "配信たすかる"]
  },
  choco: {
    id: "choco",
    name: "癒〇ちょこ",
    role: "妖艶ナース系VTuber",
    room: "assets/choco_stream_bg.jpg",
    stages: [
      { min: 0, image: "assets/choco_stage1.webp", label: "初期配信" },
      { min: 5000, image: "assets/choco_stage2.webp", label: "第2段階" },
      { min: 20000, image: "assets/choco_stage3.webp", label: "第3段階" },
      { min: 50000, image: "assets/choco_stage4.webp", label: "最終段階" },
    ],
    chat: ["癒〇ちょこちゃんの配信きた！", "ピンクの部屋かわいい", "ナース系の雰囲気いいね", "声が甘くて落ち着く", "今日も投げ銭する！"]
  },
  mel: {
    id: "mel",
    name: "夜〇メル",
    role: "小悪魔系VTuber",
    room: "assets/mel_stream_bg.jpg",
    stages: [
      { min: 0, image: "assets/mel_stage1.webp", label: "初期配信" },
      { min: 5000, image: "assets/mel_stage2.webp", label: "第2段階" },
      { min: 20000, image: "assets/mel_stage3.webp", label: "第3段階" },
      { min: 50000, image: "assets/mel_stage4.webp", label: "最終段階" },
    ],
    chat: ["夜〇メルちゃんきた！", "小悪魔っぽい雰囲気がかわいい", "今夜の配信も楽しみ", "紫の部屋が似合ってる", "たくさん応援しちゃう！"]
  },
  okayu: {
    id: "okayu",
    name: "猫〇おかゆ",
    role: "猫系VTuber",
    room: "assets/okayu_stream_bg.jpg",
    stages: [
      { min: 0, image: "assets/okayu_stage1.webp", label: "初期配信" },
      { min: 5000, image: "assets/okayu_stage2.webp", label: "第2段階" },
      { min: 20000, image: "assets/okayu_stage3.webp", label: "第3段階" },
      { min: 50000, image: "assets/okayu_stage4.webp", label: "最終段階" },
    ],
    chat: ["猫〇おかゆちゃんの配信だ！", "猫耳かわいすぎる…", "紫の配信部屋めっちゃ好き", "まったり声が癒やされる", "今日も投げ銭で応援する！"]
  }
};

const SLOT_ICONS = [
  "assets/slot_wolf.webp",
  "assets/slot_blonde.webp",
  "assets/slot_bat.webp",
  "assets/slot_purple_cat.webp",
  "assets/slot_black_cat.webp",
  "assets/slot_heart.webp",
  "assets/slot_flame.webp",
  "assets/slot_syringe.webp"
];

const $ = (id) => document.getElementById(id);
const yen = (n) => Number(n).toLocaleString("ja-JP");

function loadJson(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return value && typeof value === "object" ? value : fallback;
  } catch {
    return fallback;
  }
}

const migratedTotal = Number(localStorage.getItem("v2_totalTip") || 0);
const state = {
  money: Number(localStorage.getItem("v2_money") || 1000),
  totalTips: loadJson("v27_totalTips", { wolf: migratedTotal, choco: 0, mel: 0, okayu: 0 }),
  selectedBet: Number(localStorage.getItem("v27_selectedBet") || 100),
  characterId: localStorage.getItem("v2_characterId") || "wolf",
  log: []
};

function normalizeCharacterTotals() {
  Object.keys(CHARACTERS).forEach((id) => {
    if (typeof state.totalTips[id] !== "number") state.totalTips[id] = 0;
  });
  if (!CHARACTERS[state.characterId]) state.characterId = "wolf";
}
normalizeCharacterTotals();

function activeCharacter() {
  return CHARACTERS[state.characterId] || CHARACTERS.wolf;
}

function currentTotal() {
  return Number(state.totalTips[state.characterId] || 0);
}

function save() {
  localStorage.setItem("v2_money", String(state.money));
  localStorage.setItem("v27_totalTips", JSON.stringify(state.totalTips));
  localStorage.setItem("v2_characterId", state.characterId);
  localStorage.setItem("v27_selectedBet", String(state.selectedBet));
}

function currentStage() {
  const character = activeCharacter();
  const total = currentTotal();
  let stage = character.stages[0];
  for (const s of character.stages) {
    if (total >= s.min) stage = s;
  }
  return stage;
}

function nextStage() {
  const total = currentTotal();
  return activeCharacter().stages.find((s) => total < s.min);
}

const WOLF_FINAL_DIALOGUES = [
  "は、恥ずかしいけど…ウチのおま〇こ見えるかな…？",
  "発情期が強くてヤりまくってるから黒ずんでるけど…許してね…？",
  "ミオファのみんなで好きに使ってください♥",
];

function updateCharacterSpeech() {
  const bubble = $("characterSpeechBubble");
  if (!bubble) return;

  const character = activeCharacter();
  const stageIndex = character.stages.indexOf(currentStage());

  if (character.id === "wolf" && stageIndex === character.stages.length - 1) {
    const index = Math.floor(Date.now() / 4500) % WOLF_FINAL_DIALOGUES.length;
    bubble.textContent = WOLF_FINAL_DIALOGUES[index];
    bubble.classList.remove("hidden");
  } else {
    bubble.classList.add("hidden");
  }
}

let speechInterval = null;
function show(screen) {
  ["titleScreen", "streamScreen", "miniGameScreen"].forEach((id) => {
    const el = $(id);
    if (el) el.classList.add("hidden");
  });
  const target = $(screen);
  if (target) target.classList.remove("hidden");
  refresh();
  if (!speechInterval) speechInterval = setInterval(updateCharacterSpeech, 1200);
}

function toast(message) {
  const t = $("toast");
  if (!t) return;
  t.textContent = message;
  t.classList.remove("hidden");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.add("hidden"), 1400);
}

function setText(id, text) {
  const el = $(id);
  if (el) el.textContent = text;
}

function refresh() {
  normalizeCharacterTotals();
  save();

  const character = activeCharacter();
  const stage = currentStage();
  const total = currentTotal();
  const index = character.stages.indexOf(stage) + 1;

  const characterImage = $("characterImage");
  if (characterImage) characterImage.src = stage.image;

  const room = document.querySelector(".room-bg");
  if (room) room.src = character.room;

  const nameNode = document.querySelector(".name-card h1");
  const roleNode = document.querySelector(".name-card p");
  if (nameNode) nameNode.textContent = character.name;
  if (roleNode) roleNode.textContent = character.role;

  setText("moneyText", yen(state.money));
  setText("totalTipText", yen(total));
  setText("stageText", String(index));
  setText("miniMoneyText", yen(state.money));

  const next = nextStage();
  setText("nextUnlockText", next ? `次の解放：累計￥${yen(next.min)}で ${next.label}` : "全段階解放済み。最高ランクです。");

  document.querySelectorAll(".tip-button").forEach((btn) => {
    const amount = Number(btn.dataset.amount || 0);
    const required = Number(btn.dataset.required || 0);
    const locked = required && total < required;
    btn.classList.toggle("locked", !!locked);
    if (locked) {
      btn.textContent = `￥${yen(amount)}　累計￥${yen(required)}で解放`;
    } else {
      const label = amount >= 30000 ? "限界応援" : amount >= 10000 ? "VIP投げ銭" : amount >= 3000 ? "応援パック" : amount >= 1000 ? "ギフト" : "小さく応援";
      btn.textContent = `￥${yen(amount)}　${label}`;
    }
  });

  renderLog();
  updateCharacterSpeech();
}

function addLog(text) {
  state.log.unshift(text);
  state.log = state.log.slice(0, 8);
  renderLog();
}

function renderLog() {
  const log = $("logList");
  if (!log) return;
  log.innerHTML = state.log.map((x) => `<div class="log-line">${x}</div>`).join("");
}

function addChat(text) {
  const chat = $("chatList");
  if (!chat) return;
  const names = ["推し活勢", "夜更かし民", "匿名さん", "初見さん", "常連さん"];
  const line = document.createElement("div");
  line.className = "chat-line";
  line.innerHTML = `<strong>${names[Math.floor(Math.random() * names.length)]}</strong>：${text}`;
  chat.prepend(line);
  while (chat.children.length > 9) chat.removeChild(chat.lastChild);
}

function seedChat() {
  const chat = $("chatList");
  if (!chat) return;
  chat.innerHTML = "";
  activeCharacter().chat.slice().reverse().forEach(addChat);
}

function triggerUnlockEffect(label) {
  const effect = $("unlockEffect");
  const target = $("unlockLabel");
  if (!effect || !target) return;
  target.textContent = label;
  effect.classList.remove("hidden", "active");
  void effect.offsetWidth;
  effect.classList.add("active");
  clearTimeout(triggerUnlockEffect.timer);
  triggerUnlockEffect.timer = setTimeout(() => {
    effect.classList.remove("active");
    effect.classList.add("hidden");
  }, 1800);
}

function tip(amount, required) {
  const total = currentTotal();

  if (required && total < required) {
    addLog(`まだ解放されていません。累計￥${yen(required)}が必要です。`);
    addChat("まずは少しずつ応援して解放しよ！");
    return;
  }

  if (state.money < amount) {
    addLog("所持金が足りません。ミニゲームで稼ぎましょう。");
    addChat("ミニゲームで軍資金作ろ！");
    return;
  }

  const oldStage = currentStage();
  state.money -= amount;
  state.totalTips[state.characterId] = total + amount;
  const newStage = currentStage();

  addLog(`￥${yen(amount)} 投げ銭しました。`);
  addChat("ありがとう！ ちゃんと見えてるよ！");

  if (oldStage.image !== newStage.image) {
    addLog(`${newStage.label} が解放されました。`);
    refresh();
    const image = $("characterImage");
    if (image) {
      image.classList.add("stage-shift");
      setTimeout(() => image.classList.remove("stage-shift"), 520);
    }
    triggerUnlockEffect(newStage.label);
    return;
  }

  refresh();
}

function scratch() {
  const prizes = [0, 100, 100, 200, 300, 500, 800, 1000, 2000];
  const prize = prizes[Math.floor(Math.random() * prizes.length)];
  setText("scratchCard", prize ? `￥${yen(prize)}` : "ハズレ");
  setText("scratchResult", prize ? `￥${yen(prize)} 獲得！` : "今回はハズレ…もう一回！");

  if (prize) {
    state.money += prize;
    addLog(`スクラッチで￥${yen(prize)}獲得。`);
  } else {
    addLog("スクラッチはハズレでした。");
  }

  refresh();
}

function setReels(indices) {
  const reels = ["reel1", "reel2", "reel3"];
  reels.forEach((id, i) => {
    const el = $(id);
    if (el) el.src = SLOT_ICONS[indices[i]];
  });
}

function spin() {
  const bet = state.selectedBet;

  if (state.money < bet) {
    setText("slotMessage", "BET以上の所持金が必要です");
    addLog("スロット資金が足りません。");
    return;
  }

  state.money -= bet;

  const iconCount = SLOT_ICONS.length;
  let result = [];
  let payout = 0;
  const roll = Math.random();

  if (roll < 0.18) {
    const same = Math.floor(Math.random() * iconCount);
    result = [same, same, same];
    payout = bet * 18;
  } else if (roll < 0.60) {
    const pair = Math.floor(Math.random() * iconCount);
    let other = Math.floor(Math.random() * iconCount);
    while (other === pair) other = Math.floor(Math.random() * iconCount);
    const patterns = [[pair, pair, other], [pair, other, pair], [other, pair, pair]];
    result = patterns[Math.floor(Math.random() * patterns.length)];
    payout = bet * 4;
  } else {
    while (result.length < 3) {
      const n = Math.floor(Math.random() * iconCount);
      if (!result.includes(n)) result.push(n);
    }
  }

  ["reel1", "reel2", "reel3"].forEach((id) => {
    const el = $(id);
    if (el && el.parentElement) el.parentElement.classList.add("reels-spinning");
  });

  setTimeout(() => {
    setReels(result);
    ["reel1", "reel2", "reel3"].forEach((id) => {
      const el = $(id);
      if (el && el.parentElement) el.parentElement.classList.remove("reels-spinning");
    });
  }, 260);

  if (payout > 0) {
    state.money += payout;
    setText("slotMessage", `当たり！ ￥${yen(payout)} 獲得`);
    addLog(`スロットで￥${yen(payout)}獲得。`);
  } else {
    setText("slotMessage", `ハズレ… ￥${yen(bet)}消費`);
    addLog(`スロットで￥${yen(bet)}消費。`);
  }

  refresh();
}

function init() {
  seedChat();
  addLog("V2.7確認版を起動しました。");

  document.querySelectorAll(".title-hotspot").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.dataset.character;
      if (CHARACTERS[id]) {
        state.characterId = id;
        normalizeCharacterTotals();
        seedChat();
        show("streamScreen");
        addLog(`${activeCharacter().name}の配信に入りました。`);
      } else {
        toast("このキャラは次の更新で追加予定です");
      }
    });
  });

  const titleMini = $("titleMiniGameButton");
  if (titleMini) titleMini.addEventListener("click", () => show("miniGameScreen"));

  const titleBtn = $("toTitleFromStream");
  if (titleBtn) titleBtn.addEventListener("click", () => show("titleScreen"));

  const miniBtn = $("toMiniGameFromStream");
  if (miniBtn) miniBtn.addEventListener("click", () => show("miniGameScreen"));

  const miniToTitle = $("miniToTitle");
  if (miniToTitle) miniToTitle.addEventListener("click", () => show("titleScreen"));

  const miniToStream = $("miniToStream");
  if (miniToStream) miniToStream.addEventListener("click", () => show("streamScreen"));

  document.querySelectorAll(".tip-button").forEach((btn) => {
    btn.addEventListener("click", () => tip(Number(btn.dataset.amount), Number(btn.dataset.required || 0)));
  });

  document.querySelectorAll(".bet-button").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".bet-button").forEach((b) => b.classList.remove("selected"));
      btn.classList.add("selected");
      state.selectedBet = Number(btn.dataset.bet);
      setText("slotMessage", `BET ￥${yen(state.selectedBet)} を選択中`);
      save();
    });
    if (Number(btn.dataset.bet) === state.selectedBet) btn.classList.add("selected");
    else btn.classList.remove("selected");
  });

  const scratchButton = $("scratchButton");
  if (scratchButton) scratchButton.addEventListener("click", scratch);

  const scratchCard = $("scratchCard");
  if (scratchCard) scratchCard.addEventListener("click", scratch);

  const spinButton = $("spinButton");
  if (spinButton) spinButton.addEventListener("click", spin);

  refresh();
}

init();
