const characters = [
  {
    id: "miori",
    name: "蒼月ミオリ",
    role: "夜更かしウルフ系VTuber",
    tag: "落ち着き / 雑談",
    avatar: "linear-gradient(160deg, #2b2f5f, #a6b8ff 52%, #f6f0ff)",
    cardGradient: "linear-gradient(135deg, rgba(65,80,160,0.78), rgba(40,22,58,0.88))",
    streamGradient: "linear-gradient(135deg, #162044, #4a315f 56%, #160f22)",
    chat: ["その声、安心する…", "今日も深夜配信たすかる", "ウルフ姉さんきた！", "背景めっちゃ雰囲気ある"]
  },
  {
    id: "chocora",
    name: "黒羽ちょこら",
    role: "妖艶ナース系VTuber",
    tag: "お姉さん / 囁き",
    avatar: "linear-gradient(160deg, #2a1029, #ff7ac7 46%, #ffe5f3)",
    cardGradient: "linear-gradient(135deg, rgba(255,95,183,0.72), rgba(40,12,48,0.92))",
    streamGradient: "linear-gradient(135deg, #2a1029, #63224a 56%, #160817)",
    chat: ["お姉さん感すごい", "これは投げ銭不可避", "声の距離が近い…", "今日の衣装かわいい"]
  },
  {
    id: "melna",
    name: "金森メルナ",
    role: "きらきら吸血鬼系VTuber",
    tag: "金髪 / 甘め",
    avatar: "linear-gradient(160deg, #70420f, #ffd36a 48%, #fff4ca)",
    cardGradient: "linear-gradient(135deg, rgba(255,211,106,0.76), rgba(81,30,79,0.9))",
    streamGradient: "linear-gradient(135deg, #3a1d40, #84531f 56%, #190c20)",
    chat: ["金髪かわいすぎ", "甘やかし配信助かる", "待機してた！", "今日も眩しい"]
  },
  {
    id: "okayuna",
    name: "猫守おかゆな",
    role: "まったり猫系VTuber",
    tag: "ゆるい / 癒し",
    avatar: "linear-gradient(160deg, #3a2654, #b995ff 48%, #f1e7ff)",
    cardGradient: "linear-gradient(135deg, rgba(185,149,255,0.7), rgba(25,24,44,0.92))",
    streamGradient: "linear-gradient(135deg, #19182c, #523d75 56%, #100d19)",
    chat: ["このゆるさが最高", "眠くなる声してる", "猫っぽいのかわいい", "作業用に流したい"]
  }
];

const state = {
  selected: null,
  money: Number(localStorage.getItem("v1_money") || 3000),
  totalTip: Number(localStorage.getItem("v1_totalTip") || 0),
  rank: Number(localStorage.getItem("v1_rank") || 1),
  viewers: 128,
  log: []
};

const $ = (id) => document.getElementById(id);

function yen(num) {
  return Number(num).toLocaleString("ja-JP");
}

function save() {
  localStorage.setItem("v1_money", state.money);
  localStorage.setItem("v1_totalTip", state.totalTip);
  localStorage.setItem("v1_rank", state.rank);
}

function buildCharacterCards() {
  const grid = $("characterGrid");
  grid.innerHTML = "";
  characters.forEach((c) => {
    const button = document.createElement("button");
    button.className = "character-card";
    button.style.setProperty("--avatar", c.avatar);
    button.style.setProperty("--cardGradient", c.cardGradient);
    button.innerHTML = `
      <h2>${c.name}</h2>
      <p>${c.role}</p>
      <span class="tag">${c.tag}</span>
      <div class="mini-avatar"></div>
    `;
    button.addEventListener("click", () => selectCharacter(c.id));
    grid.appendChild(button);
  });
}

function selectCharacter(id) {
  state.selected = characters.find((c) => c.id === id);
  $("titleScreen").classList.add("hidden");
  $("gameScreen").classList.remove("hidden");

  $("characterName").textContent = state.selected.name;
  $("characterRole").textContent = state.selected.role;
  $("streamBg").style.setProperty("--streamGradient", state.selected.streamGradient);
  $("avatar").style.setProperty("--avatar", state.selected.avatar);

  state.log = [
    `${state.selected.name}が配信を開始しました。`,
    "V1: タップ表情変更はOFFです。"
  ];

  refresh();
  seedChat();
}

function getRank(total) {
  if (total >= 50000) return 5;
  if (total >= 20000) return 4;
  if (total >= 10000) return 3;
  if (total >= 5000) return 2;
  return 1;
}

function refresh() {
  state.rank = getRank(state.totalTip);
  state.viewers = 128 + Math.floor(state.totalTip / 120) + state.rank * 8;

  $("moneyText").textContent = yen(state.money);
  $("totalTipText").textContent = yen(state.totalTip);
  $("rankText").textContent = state.rank;
  $("viewerText").textContent = yen(state.viewers);
  $("unlockText").textContent = unlockText();

  document.querySelectorAll(".tip").forEach((button) => {
    const required = Number(button.dataset.required || 0);
    const tip = Number(button.dataset.tip);
    if (required && state.totalTip < required) {
      button.classList.add("locked");
      button.textContent = `${yen(tip)}円 / 累計${yen(required)}円で解放`;
    } else {
      button.classList.remove("locked");
      const labels = {
        "240": "240円 スパチャ",
        "1000": "1000円 ギフト",
        "3000": "3000円 応援パック",
        "10000": "10000円 VIP投げ銭"
      };
      button.textContent = labels[String(tip)];
    }
  });

  renderLog();
  save();
}

function unlockText() {
  if (state.totalTip < 5000) return "累計5,000円で 3000円応援パック 解放";
  if (state.totalTip < 20000) return "累計20,000円で 10000円VIP投げ銭 解放";
  if (state.totalTip < 50000) return "次の目標: 累計50,000円でランク5";
  return "最高ランク到達。あとは推し活あるのみ。";
}

function addLog(text) {
  state.log.unshift(text);
  state.log = state.log.slice(0, 8);
  renderLog();
}

function renderLog() {
  $("reactionLog").innerHTML = state.log
    .map((item) => `<div class="log-item">${item}</div>`)
    .join("");
}

function seedChat() {
  const chat = $("chatList");
  chat.innerHTML = "";

  const baseLines = state.selected.chat;
  for (let i = 0; i < 9; i++) {
    const line = document.createElement("div");
    line.className = "chat-line";
    line.innerHTML = `<strong>user${100 + i}</strong>：${baseLines[i % baseLines.length]}`;
    chat.prepend(line);
  }
}

function addChat(text) {
  const chat = $("chatList");
  const line = document.createElement("div");
  line.className = "chat-line";
  line.innerHTML = `<strong>user${Math.floor(Math.random() * 899 + 100)}</strong>：${text}`;
  chat.prepend(line);

  while (chat.children.length > 11) {
    chat.removeChild(chat.lastChild);
  }
}

function tip(amount, required) {
  if (required && state.totalTip < required) {
    addLog(`まだ解放条件に届いていません。累計${yen(required)}円が必要です。`);
    return;
  }

  if (state.money < amount) {
    addLog("所持金が足りません。先に稼ぐメニューで資金を増やしましょう。");
    addChat("無理せず推してこ！");
    return;
  }

  state.money -= amount;
  state.totalTip += amount;

  const reactions = [
    `${state.selected.name}「ありがとう、すっごく嬉しい！」`,
    `${state.selected.name}「今の投げ銭、ちゃんと見えてるよ！」`,
    `${state.selected.name}「今日も応援してくれてありがとね」`,
    `${state.selected.name}「えへへ、配信がもっと楽しくなってきた！」`
  ];

  addLog(`${yen(amount)}円を投げ銭しました。`);
  addChat(reactions[Math.floor(Math.random() * reactions.length)]);
  refresh();
}

function earn(amount, label) {
  state.money += amount;
  addLog(`${label}で ${yen(amount)}円 稼ぎました。`);
  addChat("ナイス作業！");
  refresh();
}

function init() {
  buildCharacterCards();

  $("backButton").addEventListener("click", () => {
    $("gameScreen").classList.add("hidden");
    $("titleScreen").classList.remove("hidden");
  });

  document.querySelectorAll(".tip").forEach((button) => {
    button.addEventListener("click", () => {
      tip(Number(button.dataset.tip), Number(button.dataset.required || 0));
    });
  });

  $("earnButton").addEventListener("click", () => earn(600, "配信準備バイト"));
  $("clipButton").addEventListener("click", () => earn(1200, "切り抜き投稿"));
}

init();
